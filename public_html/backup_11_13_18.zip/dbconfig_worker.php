<?php
    define('HOST','localhost');
	define('USER','armapprise_armavi');
	define('PASS','unicornvirusadmin1234');
	define('DB','armapprise_vision');
	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 
?>