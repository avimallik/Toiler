<!DOCTYPE html>
<html lang="en">
<head>
  <title>Postarium</title>
  <link rel="stylesheet" type="text/css" href="css/style.css" />

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type='text/javascript' src='javascript/view_filter.js'></script> 

  <style>
* {
  box-sizing: border-box;
  }

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myUL {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

#myUL li a {
  border: 1px solid #ddd;
  margin-top: -1px; /* Prevent double borders */
  background-color: #f6f6f6;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  color: black;
  display: block
}

#myUL li a:hover:not(.header) {
  background-color: #eee;
}

.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #222222;
   color: #A8A8A8;
   text-align: center;
}

body {
      padding-top: 50px; /* Required padding for .navbar-fixed-top. Change if height of navigation changes. */
      background-color: ;
  }
  
  .navbar-fixed-top .nav {
      padding: 15px 0;
  }
  
  .navbar-fixed-top .navbar-brand {
      padding: 0 15px;
  }
  
  @media(min-width:768px) {
      body {
          padding-top: 70px; /* Required padding for .navbar-fixed-top. Change if height of navigation changes. */
          background:;
      }
  
      .navbar-fixed-top .navbar-brand {
          padding: 15px 0;
      }
    }

    .footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: #222222;
        color: #A8A8A8;
        text-align: center;
     }
  </style>
</head>

<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">
            <img src="http://placehold.it/150x50&amp;text=Logo" alt="">
        </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
            <li>
                <a href="index.php"><font size = 3pt><b>Home</b></font></a>
            </li>
            <li>
                <a href="districtgrid.php"><font size = 3pt><b>Postlist</b></font></a>
            </li>
            <li>
                <a href="#"><font size = 3pt><b>Armapprise</b></font></a>
            </li>
        </ul>

        <ul class="nav navbar-nav navbar-right">
        <li>
        <form class="navbar-form navbar-left" action="/action_page.php">
      <div class="form-group">
        <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Search for District">
        </li>
        </ul>

      </div>
    </form>
    </div>
    <!-- /.navbar-collapse -->
</div>
<!-- /.container -->
</nav>

<br>
<div class = "container" style = "width:500px">
<?php
include ("dbconfig.php");
// Check connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM rajshahi";
$result = mysqli_query($db, $sql);

        echo "<ul id='myUL'>";
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
            echo "<li>";
            echo "<a href='#'>" ;
            echo "<center><img src ="."uploadedimage/".$row['image']." height = '110' width = '200'>" . "</th>"."</center>";
            echo "<font size = '2pt'>District Name:"." "."<b>".$row["districtname"]."<br>"."</font>";
            echo "<font size = '2pt'>Postal Code:"." "."<b>".$row["postcode"]."</font>";
            echo "<p><font size = '2pt'>Thana Phone:"." "."<b>".$row["thanaphone"]."</font>";
            echo "<p><font size = '2pt'>Division:"." "."<b>".$row["division"]."</font>";

       
          echo "</a>";
          echo "</li>";
   

    }
} else {
   
}

// echo "</li>";
echo "</ul>";

mysqli_close($db);
?> 
</div>



</body>
</html>