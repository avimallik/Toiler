<?php
if($_SERVER['REQUEST_METHOD']=='POST'){

include 'dbConnect.php';

 $id = $_POST['id'];
 $username = $_POST['username'];
 $name = $_POST['name'];
 $email = $_POST['email'];
//  $pic = $_POST['image'];
 
//  $rand_id = rand();
//  $filePath = "dp/$rand_id.jpg";
//  $url = "http://www.armapprise.com/dp/$rand_id.jpg";
 
 $Sql_Query = "UPDATE user SET username = '$username', name = '$name', email = '$email' WHERE id = $id";
 
//  $update = mysqli_query($conn,"UPDATE `user` SET `pic`='$url' WHERE `id`='$id'");
 
 if(mysqli_query($conn,$Sql_Query))
{
  file_put_contents($filePath,base64_decode($pic));
  echo 'Record Updated Successfully';
}
else
{
 echo 'Something went wrong';
 }
}
 mysqli_close($con);
?>