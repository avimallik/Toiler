<?php
$username = $_POST["username"];
$image = $_POST["image"];
include("dbConnect.php");
$response=array();
$response["success"]=false;
$check=mysqli_query($conn,"SELECT * FROM `user` WHERE `username`='$username'");
$affected=mysqli_affected_rows($conn);
if($affected>0){
  $response["status"]="USERNAME";
}
else{
  $fetchId=mysqli_query($conn,"SELECT `id` FROM `user` WHERE `username`='$username'");
  $id=0;
  while($rowid=mysqli_fetch_array($fetchId,MYSQLI_ASSOC)){
    $id=$rowid['id'];
  }
  $filePath = "dp/$id.jpg";
  $url = "http://www.armapprise.com/dp/$id.jpg";
  $update=mysqli_query($conn,"UPDATE `user` SET `pic`='$url' WHERE `id`='$username'");
  if($update){
    file_put_contents($filePath,base64_decode($image));
    $response["success"]=true;
  }
}
echo json_encode($response);#encoding RESPONSE into a JSON and returning.
mysqli_close($conn);
exit();
?>