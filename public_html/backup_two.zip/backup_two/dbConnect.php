<?php
$conn=mysqli_connect("localhost","armapprise_test","unicornvirusadmin1234","armapprise_test");
if(!$conn)
{  
  mysqli_error();
  die();
}
?>