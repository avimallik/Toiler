<?php

if($_SERVER['REQUEST_METHOD']=='POST'){

include 'dbConnect.php';

 $id = $_POST['id'];

$sql = "SELECT * FROM user where id = '$id'" ;

$result = $conn->query($sql);

if ($result->num_rows >0) {
 
 
 while($row[] = $result->fetch_assoc()) {
 
 $tem = $row;
 
 $json = json_encode($tem);
 
 }
 
} else {
 echo "No Results Found.";
}
 echo $json;

$conn->close();
}
?>