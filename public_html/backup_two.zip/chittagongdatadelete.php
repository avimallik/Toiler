<?php
include("dbconfig.php");

  $id = mysqli_real_escape_string($db, $_GET['id']);
  
  // $id = isset($_GET['id']) ? $_GET['id'] : '';
    // sql to delete a record
  $sql = "DELETE FROM chittagong WHERE id=$id";
  
  if (mysqli_query($db, $sql)) {
      // echo "Record deleted successfully";
      header("Location:chittagongdataview.php");
  } else {
      echo "Error deleting record: " . mysqli_error($db);
  }



mysqli_close($db);
?>