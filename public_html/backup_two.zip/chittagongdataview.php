
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
  <script type='text/javascript' src='javascript/filter.js'></script> 

  <style>

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
    border-right:1px solid #bbb;
}

li:last-child {
    border-right: none;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: #111;
}

.active {
    background-color: #4CAF50;
}
#myInput{
	padding: 13px;
}

      #myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 15px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
  </style>
</head>

<body>

<ul>
<li><a class="active">
<font color=white size=4pt><b>Chittagong's District List</b></font><br>

</a>
</li>

<li><a href="data_insert_ui.php">Admin Panel</a></li>


<li style="float:right"><a href="#contact"><b>Log Out</b></a></li>

</ul>

<div class="container">
 <br>
 <h1>Filter Data</h>
  <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for District" title="Type in a name">

</div>
<br>


<?php
include ("dbconfig.php");
// Check connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM chittagong";
$result = mysqli_query($db, $sql);

        echo "<div class='container' id = 'div_data_disp'>";
        echo "<div class='row-fluid'>";

        echo "<table class = 'table table-hover' id = 'myTable'>";
        echo "<thead>";
        echo "<tr>";
       
        echo "<th>District Name</th>";
        echo "<th>Postal Code</th>";
        echo "<th>Thanaphone</th>";
        echo "<th>Division</th>";
        echo "<th>Image</th>";
         echo "<th>Operation</th>";
        echo "</tr>";
        echo "</thead>";

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        // echo " Name: " . $row["name"]. " - Age: " . $row["age"]. " Post: " . $row["post"]. "<br>";
        $id = $row["id"];
        $division = $row["division"];
        $sum = "id={$id} & division={$division}";

        echo "<tbody>";
        echo "<tr>";
       
        echo "<td>" . $row["districtname"] . "</td>";
        echo "<td>" . $row["postcode"] . "</td>";
        echo "<td>" . $row["thanaphone"] . "</td>";
        echo "<td>" . $row["division"] . "</td>";

        echo "<td>" . "<img src ="
        ."uploadedimage/"
        .$row['image']." height = '100' width = '100'>" . "</td>";
        // echo "<td>" . "<a href = 'dataedit.php? id=".$row["id"]"'>"  . 'edit' .   "</a>"  .    "</td>"; 
        echo "<td>  
        
                    <a href='edit.php?".$sum."' class='btn btn-success' role='button'><img src = 'image/edit.png'/></a>

                    <a href='chittagongdatadelete.php?id=".$row['id']."' class='btn btn-danger' role='button'><img src = 'image/delete.png'/></a>
                    
              </td>";
        echo "</tr>";	
        echo "</tbody>";	

    }
} else {
   
}

echo "</table>";
mysqli_close($db);
?> 




</body>
</html>