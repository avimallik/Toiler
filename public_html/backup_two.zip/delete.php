<?php

$id = $_POST['name'];
  // sql to delete a record
$sql = "DELETE FROM sylhet WHERE id=$id";

if (mysqli_query($db, $sql)) {
    // echo "Record deleted successfully";
    header("Location: data_insert_ui.php");
} else {
    echo "Error deleting record: " . mysqli_error($db);
}

mysqli_close($db);


?>