<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



  <style>
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    -webkit-animation-name: fadeIn; /* Fade in the background */
    -webkit-animation-duration: 0.4s;
    animation-name: fadeIn;
    animation-duration: 0.4s
}

/* Modal Content */
.modal-content {
    position: fixed;
    bottom: 0;
    background-color: #fefefe;
    width: 100%;
    -webkit-animation-name: slideIn;
    -webkit-animation-duration: 0.4s;
    animation-name: slideIn;
    animation-duration: 0.4s
}

/* The Close Button */
.close {
    color: white;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}

.modal-header {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

.modal-body {padding: 2px 16px;}

.modal-footer {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

/* Add Animation */
@-webkit-keyframes slideIn {
    from {bottom: -300px; opacity: 0} 
    to {bottom: 0; opacity: 1}
}

@keyframes slideIn {
    from {bottom: -300px; opacity: 0}
    to {bottom: 0; opacity: 1}
}

@-webkit-keyframes fadeIn {
    from {opacity: 0} 
    to {opacity: 1}
}

@keyframes fadeIn {
    from {opacity: 0} 
    to {opacity: 1}
}

form {
    border: 3px solid #f1f1f1;
}

input[type=text], input[type=password] {
    width: 100%;
    padding: 8px 15px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    opacity: 0.8;
}

.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
</style>

</head>
<body>


<?php

// $divname = mysqli_real_escape_string($db, $_GET['divname']);
include ("dbconfig.php");
// Create connection
// Check connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_GET['id'])) {
    $txt= $_GET['id'];
    $div = $_GET["division"];
    $result = mysqli_query($db,"SELECT * FROM $div where id=" . $txt);
    echo "<table>";
    while($row = mysqli_fetch_array($result)) 
    { 
    // echo "<tr>"; 
    // echo "<td>" . $row['name'] . "</td>" ."<br>"; 
    // echo "<td>" . $row['age'] . "</td>"; 
    // echo "<td>" . $row['post'] . "</td>"; 
    // echo "</tr>"; 

    // echo '<div class="form-group">';
    //    echo "<label>ID : " . $row['id'] . "</label>";
    // echo '</div>';

       $id = $row["id"];
       $districtname = $row["districtname"];
       $postcode = $row["postcode"];
       $thanaphone = $row["thanaphone"];
       $division = $row["division"];

    } 
    mysqli_close($db);
  }

?> 
<br><br>



<form action="" method = "post">
  <div class="imgcontainer">
    <img src="image/edit_avatar.png" alt="Avatar" >
  </div>

  <div class="container">
  <div class = "row">
    <div class = "col-sm-6"><input type="text" name = "id" value = "<?php echo $id; ?>" readonly ></div>
    <div class = "col-sm-6"><input type="text" name = "division" value = "<?php echo $division;?>" readonly > </div>
  </div>
</div>
</div>

  <div class="container">

    <label><b>District Name</b></label>
    <input type="text" placeholder="Enter District Name" name = "districtname" value = "<?php echo $districtname;?>">

    <label><b> Postal Code</b></label>
    <input type="text" placeholder="Enter Postal Code" name = "postcode" value = "<?php echo $postcode;?>">

    <label><b>Thana Phone number</b></label>
    <input type="text" placeholder="Enter Thana Phone" name = "thanaphone" value = "<?php echo $thanaphone;?>">


        
    <button type="update" name = "update">Update</button>
    
  </div>



  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn" onclick="window.location.href='data_insert_ui.php'">Cancel</button>
  </div>
</form>

<!-- <div class="container">
  <div class="jumbotron">    
    <p>Edit Data</p>
    <form action = "" method = "post">

  <div class="form-group">
      <label>ID:</label>
      <input type="text" class="form-control"  placeholder="Enter Name" name="id" value = <?php echo $id; ?> readonly >
      <label>Division:</label>
      <input type="text" class="form-control"  placeholder="Enter Post" name="division" value = "<?php echo $division;?>" readonly >
    </div>

    <div class="form-group">
      <label>District Name:</label>
      <input type="text" class="form-control"  placeholder="Enter Name" name="districtname" value = "<?php echo $districtname; ?>">
    </div>

    <div class="form-group">
      <label>Postal Code:</label>
      <input type="text" class="form-control"  placeholder="Enter Age" name="postcode" value = "<?php echo $postcode;?>">
    </div>

    <div class="form-group">
      <label>Thana Phone Number:</label>
      <input type="text" class="form-control"  placeholder="Enter Post" name="thanaphone" value = "<?php echo $thanaphone;?>">
    </div>
    <button type="submit" class="btn btn-default" name = "update">Update</button>
   </form>
  </div>
  
</div> -->


<?php
include ("dbconfig.php");
if(isset($_POST['update'])){
  $id = $_POST["id"];
  $districtname = $_POST["districtname"];
  $postcode = $_POST["postcode"];
  $thanaphone = $_POST["thanaphone"];
  $division = $_POST["division"];
  
  $sql = "UPDATE $division SET districtname = '$districtname', postcode = $postcode , thanaphone = '$thanaphone' WHERE id=$id";
  
  if (mysqli_query($db, $sql)) {
    echo "
    <script type=\"text/javascript\">
   alert('Are You Sure to Update Data');
    </script>";
      
  } else {
      echo "Error updating record: " . mysqli_error($db);
  }
  
  
  mysqli_close($db);
}


?>

</div>



</body>
</html>