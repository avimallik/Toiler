<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Webpage Home</title>
</head>


<body style = "background-color: #838483;">
<?php include("navbar.php"); ?>
<br>
<div class="container">

  <div class="row">
    <div class="col-md-4" >
      <div class="thumbnail">
        <a href="userview_sylhet.php" target="_blank">
          <img src="image/sylhetphoto.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <p><b>Sylhet</b></p>
          </div>
        </a>
      </div>
    </div>

    <div class="col-md-4">
      <div class="thumbnail">
        <a href="userview_dhaka.php" target="_blank">
          <img src="image/dhakaphoto.jpg" alt="Nature" style="width:100%">
          <div class="caption">
            <p><b>Dhaka</b></p>
          </div>
        </a>
      </div>
    </div>

    <div class="col-md-4">
      <div class="thumbnail">
        <a href="userview_chittagong.php" target="_blank">
          <img src="image/chittagongphoto.jpg" alt="Fjords" style="width:100%">
          <div class="caption">
            <p><b>Chittagong</b></p>
          </div>
        </a>
      </div>
    </div>




  </div>
</div>


<div class="container">

  <div class="row">
    <div class="col-md-4" >
      <div class="thumbnail">
        <a href="userview_khulna.php" target="_blank">
          <img src="image/khulnaphoto.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <p><b>Khulna</b></p>
          </div>
        </a>
      </div>
    </div>

    <div class="col-md-4">
      <div class="thumbnail">
        <a href="userview_rajshahi.php" target="_blank">
          <img src="image/rajshahiphoto.jpg" alt="Nature" style="width:100%">
          <div class="caption">
            <p><b>Rajshahi</b></p>
          </div>
        </a>
      </div>
    </div>

    <div class="col-md-4">
      <div class="thumbnail">
        <a href="userview_barisal.php" target="_blank">
          <img src="image/barisalphoto.jpg" alt="Fjords" style="height:228px">
          <div class="caption">
            <p><b>Barisal</b></p>
          </div>
        </a>
      </div>
    </div>




  </div>
</div>


<div class="container">

  <div class="row">
    <div class="col-md-4" >
      <div class="thumbnail">
        <a href="userview_rangpur.php" target="_blank">
          <img src="image/rangpurphoto.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <p><b>Rangpur</b></p>
          </div>
        </a>
      </div>
    </div>

    <div class="row" >
    <div class="col-md-4" style= "width:390px">
      <div class="thumbnail">
        <a href="userview_mymensingh.php" target="_blank">
          <img src="image/mymensinghphoto.jpg" alt="Lights" style="width:100%; height:228px">
          <div class="caption">
            <p><b>Mymensingh</b></p>
          </div>
        </a>
      </div>
    </div>


  </div>
</div>








</body>
</html>