<?php
//including the database connection file
include_once("dbconfig.php");
include('session.php'); 

if(isset($_POST['Submit'])) {	
	$devselect = mysqli_real_escape_string($db, $_POST['devselect']);
	$districtname = mysqli_real_escape_string($db, $_POST['districtname']);
	$postcode = mysqli_real_escape_string($db, $_POST['postcode']);
	$thanaphone = mysqli_real_escape_string($db, $_POST['thanaphone']);
	$image = $_FILES['image']['name'];
	$target = "uploadedimage/".basename($image);
	// $divSelectFixedVal = $divselect;
	
	// if($divSelectFixedVal == "sylhet")
	// {
	// 	$divSelectFixedVal = "sylhet";
		
	// }else if($divSelectFixedVal == "chittagong")
	// {
	// 	$divSelectFixedVal = "chittagong";
		
	// }else if($divSelectFixedVal == "dhaka")
	// {
	// 	$divSelectFixedVal = "dhaka";
		
	// }else if($divSelectFixedVal == "rajshahi")
	// {
	// 	$divSelectFixedVal = "rajshahi";
		
	// }else if($divSelectFixedVal == "mymensingh")
	// {
	// 	$divSelectFixedVal = "mymensingh";
		
	// }else if($divSelectFixedVal == "rangpur")
	// {
	// 	$divSelectFixedVal = "rangpur";
		
	// }else if($divSelectFixedVal == "barisal")
	// {
	// 	$divSelectFixedVal = "barisal";
		
	// }else if($divSelectFixedVal == "khulna")
	// {
	// 	$divSelectFixedVal = "khulna";
		
	// } 

	// checking empty fields
	if(empty($districtname) || empty($postcode) || empty($thanaphone)) {
				
		// if(empty($districtname)) {
		// 	echo '<script language="javascript">';
		// 	echo 'alert("Input District Name !")';
		// 	echo '</script>';
		// }
		
		// if(empty($postcode)) {
		// 	echo '<script language="javascript">';
		// 	echo 'alert("Input District Postal Code !")';
		// 	echo '</script>';
		// }
		
		// if(empty($thanaphone)) {
		// 	echo '<script language="javascript">';
		// 	echo 'alert("Input District Thanaphone Number !")';
		// 	echo '</script>';
		// }

		    echo '<script language="javascript">';
			echo 'alert("Some Field is Empty You Must Insert Suitable Data On It !")';
		    echo '</script>';
		
		//link to the previous page
		
	} else { 
		 
		if($devselect == "empty"){
			echo '<script language="javascript">';
			echo 'alert("Select Prefeared Division For Insert !")';
			echo '</script>';
		}else{
			$sql = "INSERT INTO $devselect (districtname, postcode, thanaphone,division, image) VALUES ('$districtname','$postcode','$thanaphone','$devselect','$image')";
			mysqli_query($db, $sql);
	        header ('Location:data_insert_ui.php');
	//display success message
	echo "<font color='green'>Data added successfully.";
	echo "<br/><a href='index.php'>View Result</a>";
		}
	}
	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
		$msg = "Image uploaded successfully";
}else{
		$msg = "Failed to upload image";
	}

}
?>




<!DOCTYPE html>
<html lang="en">
<head>

<title>Bootstrap Example</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>

<style>
/* body, html {
  margin: 0;
  overflow: hidden;
  height:100%;
}

@media (min-width: 768px){

  #right {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    overflow-y: scroll;
    width: 100%;
  }
}*/
 
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
    border-right:1px solid #bbb;
}

li:last-child {
    border-right: none;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: #111;
}

.active {
    background-color: #4CAF50;
}
#myInput{
	padding: 13px;
}

.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #111;
   color: white;
   text-align: center;
   height:32px;
   padding :5px 2px 5px;
}

#destroy{
	padding:16px 16px 13px 30px;
}

</style>


</head>

<body>


<!--nav bar-->

<ul>
<li><a class="active">
<font color=white size=4pt><b>Postarium Admin Panel</b></font><br>

</a>
</li>

<li><a href="#news">About</a></li>
<li><a href="#contact">Contact</a></li>

<li style="float:right">
<a href="logout.php">logout</a> 
</li>

</ul>
  
  <!--search Script-->

<br>
<div class="container-fluid">

<div class="row" style = " height:516px">

<div class="col-sm-2">
</div>

    <div class="col-sm-8">
    <!-- <form action="data_insert_ui.php" method="post" name="form1" enctype="multipart/form-data">
		<table width="25%" border="0">
			<tr> 
				<td>District</td>
				<td><input type="text" name="districtname"></td>
			</tr>
			<tr> 
				<td>Post</td>
				<td><input type="text" name="postcode"></td>
			</tr>
			<tr> 
				<td>Thana</td>
				<td><input type="text" name="thanaphone"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="file" name="image"></td>
			</tr>
			<tr> 
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
	
		</table>
	</form> -->





	<form class="form-horizontal" action="data_insert_ui.php" method="post" name="form1" enctype="multipart/form-data">

	<div class="form-group has-error">
        <label class="col-xs-2 control-label" for="inputError">Select Division</label>
        <div class="col-xs-10">
		<select id=test name = "devselect">
		   <option value = empty>Select Division</option>
           <option value = dhaka>Dhaka</option>
           <option value = sylhet>Sylhet</option>
           <option value = chittagong>Chittagong</option>
		   <option value = rajshahi>Rajshahi</option>
           <option value = khulna>Khulna</option>
           <option value = mymensingh>Mymensingh</option>
		   <option value = rangpur>Rangpur</option>
           <option value = barisal>Barisal</option>
        </select>
       </div>
    </div>

    <div class="form-group has-success">
        <label class="col-xs-2 control-label" for="inputSuccess">District name</label>
        <div class="col-xs-10">
            <input type="text" id="inputSuccess" class="form-control" placeholder="Input District Name" name="districtname">
           
        </div>
    </div>
    <div class="form-group has-warning">
        <label class="col-xs-2 control-label" for="inputWarning">Postal Code</label>
        <div class="col-xs-10">
            <input type="text" id="inputWarning" class="form-control" placeholder="Input Postal Code" name="postcode">
           
        </div>
    </div>
    <div class="form-group has-error">
        <label class="col-xs-2 control-label" for="inputError">Thana Phone Number</label>
        <div class="col-xs-10">
            <input type="text" id="inputError" class="form-control" placeholder="Input Thana Phone Number" name="thanaphone">
            
        </div>
    </div>

    <div class="form-group has-error">
        <label class="col-xs-2 control-label" for="inputError">
		
		Upload Image
				<input type='file' name='image' />

		</label>
       
    </div>


		<div class="form-group">
        <div class="col-xs-offset-2 col-xs-10">
            <button type="submit" class="btn btn-primary" name="Submit" >Save Data</button> 
						
					  <button class="btn btn-primary" name="reset" id = "reset">Clear field</button>

        </div>
    </div>

<div class = "container-fluid" style = " background-color: #b5b5b5;padding:4px 20px 23px;height:47px">
		<div class="form-group">
        <div class="col-sm-12">
		<center>
		<a href="sylhetdataview.php" class="btn btn-success" role="button">Sylhet</a>
		<a href="dhakadataview.php" class="btn btn-success" role="button">Dhaka</a>
		<a href="chittagongdataview.php" class="btn btn-success" role="button">Chittagong</a>
		<a href="rajshahidataview.php" class="btn btn-success" role="button">Rajshahi</a>
		<a href="khulnadataview.php" class="btn btn-success" role="button">Khulna</a>
		<a href="mymensinghdataview.php" class="btn btn-success" role="button">Mymensingh</a>
		<a href="rangpurdataview.php" class="btn btn-success" role="button">Rangpur</a>
		<a href="barisaldataview.php" class="btn btn-success" role="button">Barisal</a>
        </div>
		</center>
        </div>

		<div class="form-group">
        <div class="col-xs-offset-2 col-xs-10">
		    
		
        </div>
        </div>
 </div>		

</form>
</div>
  
<div class="col-sm-2">
</div>


<div class="footer">
  <p>PostariumⒸ Powered By <b>Arm Avi</br></p>
</div>


</body>
</html>