<?php
  $db =  mysqli_connect("localhost", "armapprise_postarium", "unicornvirusadmin1234", "armapprise_postarium");
  $msg = "";

  if($db === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
  }
  ?>