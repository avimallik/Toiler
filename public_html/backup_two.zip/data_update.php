<?php
include ("dbconfig.php");

$id = $_POST["id"];
$districtname = $_POST["districtname"];
$postcode = $_POST["postcode"];
$thanaphone = $_POST["thanaphone"];
$division = $_POST["division"];

$sql = "UPDATE $division SET districtname = '$districtname', postcode = $postcode , thanaphone = '$thanaphone' WHERE id=$id";

if (mysqli_query($db, $sql)) {
    // echo "Record updated successfully";

} else {
    echo "Error updating record: " . mysqli_error($db);
}


mysqli_close($db);

?>
