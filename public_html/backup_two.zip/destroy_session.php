<?
  if(isset($_POST['destroy'])){
    // session_start();
    // session_destroy();
    header('Location:data_insert_ui.php');
  }
?>