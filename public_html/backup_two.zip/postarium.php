<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title>Webpage Home</title>

<style>
.footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #222222;
   color: #A8A8A8;
   text-align: center;
}
</style>

</head>


<body style = "background-color: #838483;">
<?php include("navbar.php"); ?>

<div class="jumbotron text-center" style="background-image:url('image/back_four.jpg') !important;">
<h1><font color = #a8a8a8><b>Postarium</b></font></h1>
<p><font color = #a8a8a8>The Hady Tool Of Bangladeshi Postal Code</font></p> 
</div>

<br>
<div class="container" >
<div class="row">
  <div class="col-sm-4">
    <img src = "image/androidphone.png" width = 100 height = 100/>
    <br> <br>  
    <p>
        <b>Lorem ipsum dolor sit amet, consectetur adipisicing elit..
    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.
        </b>
     </p>   
  </div>

  <div class="col-sm-4 ">
   <img src = "image/search.png" width = 100 height = 100/>
    <br> <br>  
    <p>
            <b>Lorem ipsum dolor sit amet, consectetur adipisicing elit..
        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.
            </b>
         </p>   
  </div>
  <div class="col-sm-4">
        <img src = "image/apilogo_two.png"  height = 100/>   
        <br> <br>  
        <p>
        <b>Lorem ipsum dolor sit amet, consectetur adipisicing elit..
    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.
        </b>
     </p>   
  </div>
</div>
</div>

<br><br><br><br>

<!-- <div class="footer">
<br>
<p>Postarium © all right reserved Arunav Mallik Avi (Arm Avi) </p>
</div> -->

<div class="footer">
<br>
<p>Postarium © all right reserved Arunav Mallik Avi (Arm Avi) </p>
</div>


</body>
<!--  -->
</html>